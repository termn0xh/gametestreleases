using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadMap1Button : MonoBehaviour
{
    // This method can be hooked to the Button's OnClick() event
    public void LoadMap1ButtonX()
    {
        SceneManager.LoadScene(1); // Loads scene with build index 1 (Map1)
    }
}
