using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
public class ButtonMovement : MonoBehaviour
{
    private Rigidbody2D rb;
    private PlayerInputActions inputActions;

    public float moveSpeed = 5f;
    public float jumpForce = 10f;
    public float accelerationTime = 0.1f; // Lower = faster response

    private bool isGrounded = true;
    private float inputDirection = 0f;
    private float velocityXSmoothing = 0f;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        inputActions = new PlayerInputActions();

        inputActions.Player.Jump.performed += ctx => Jump();
    }

    private void OnEnable()
    {
        inputActions.Enable();
    }

    private void OnDisable()
    {
        inputActions.Disable();
    }

    void Update()
    {
        inputDirection = inputActions.Player.Move.ReadValue<float>();

        float targetVelocityX = inputDirection * moveSpeed;
        float smoothedVelocityX = Mathf.SmoothDamp(rb.linearVelocity.x, targetVelocityX, ref velocityXSmoothing, accelerationTime);

        rb.linearVelocity = new Vector2(smoothedVelocityX, rb.linearVelocity.y);
    }

    void Jump()
    {
        if (isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            isGrounded = false;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }
}