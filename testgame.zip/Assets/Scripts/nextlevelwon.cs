using UnityEngine;
using UnityEngine.SceneManagement;

public class nextlevelwon : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Door1to5"))
        {
          SceneManager.LoadScene(5);
        }
    }
}
