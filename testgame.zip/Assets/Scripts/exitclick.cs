using UnityEngine;
using UnityEngine.SceneManagement;  // In case you want to load a scene before quitting.

public class ExitGameButton : MonoBehaviour
{
    public void ExitGame()
    {
        // If we are running the game in the editor, stop playing the game
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            // If we are running in a build, quit the application
            Application.Quit();
        #endif
    }
}
