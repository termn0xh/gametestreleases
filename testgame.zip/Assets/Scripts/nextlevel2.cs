using UnityEngine;
using UnityEngine.SceneManagement;

public class nextlevel2 : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Door1to4"))
        {
          SceneManager.LoadScene(4);
        }
    }
}
