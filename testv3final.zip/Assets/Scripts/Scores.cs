﻿using UnityEngine;
using TMPro;

public class PlayerCoinCollector : MonoBehaviour
{
    public static int totalCoins = 0; // Static so it persists across scenes
    public TMP_Text scoreText;

    private void Start()
    {
        UpdateScoreUI();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("coin"))
        {
            totalCoins += 1;
            Destroy(collision.gameObject);
            UpdateScoreUI();

            // Save high score if it's a new record
            int currentHighScore = PlayerPrefs.GetInt("HighScore", 0);
            if (totalCoins > currentHighScore)
            {
                PlayerPrefs.SetInt("HighScore", totalCoins);
                PlayerPrefs.Save(); // Ensure it's written to disk
            }
        }
    }

    private void UpdateScoreUI()
    {
        if (scoreText != null)
        {
            scoreText.text = "Score: " + totalCoins.ToString();
        }
    }
}
