using UnityEngine;

public class CoinCollector : MonoBehaviour
{
    [Header("Audio")]
    [Tooltip("Sound that plays when a coin is collected")]
    public AudioClip coinSound; // Assign this in the Unity Inspector

    private AudioSource audioSource;

    void Start()
    {
        // Get or add an AudioSource component
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("coin"))
        {
            // Play the assigned coin sound
            if (coinSound != null)
            {
                audioSource.PlayOneShot(coinSound);
            }
            else
            {
                Debug.LogWarning("Coin sound is not assigned in the Inspector.");
            }

            // Optionally destroy the coin after collection
            Destroy(other.gameObject);
        }
    }

    // Optional: You can set the sound from another script if needed
    public void SetCoinSound(AudioClip newClip)
    {
        coinSound = newClip;
    }
}
