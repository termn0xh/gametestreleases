using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using System.Collections;

public class CountdownTimer : MonoBehaviour
{
    public static int remainingSeconds = -1; // -1 means not started yet
    public TMP_Text timerText;

    private void Start()
    {
        // Only set once
        if (remainingSeconds < 0)
        {
            remainingSeconds = 3 * 60; // 3 minutes
            StartCoroutine(CountdownRoutine());
        }
        else
        {
            // Already counting in another scene — just update the text
            UpdateTimerUI();
            StartCoroutine(CountdownRoutine());
        }
    }

    private IEnumerator CountdownRoutine()
    {
        while (remainingSeconds > 0)
        {
            UpdateTimerUI();
            yield return new WaitForSeconds(1f);
            remainingSeconds--;
        }

        UpdateTimerUI();

        if (SceneManager.GetActiveScene().buildIndex != 2)
        {
            SceneManager.LoadScene(2);
        }
    }

    private void UpdateTimerUI()
    {
        if (timerText != null)
        {
            int minutes = remainingSeconds / 60;
            int seconds = remainingSeconds % 60;
            timerText.text = string.Format("{0:0}:{1:00}", minutes, seconds);
        }
    }
}
