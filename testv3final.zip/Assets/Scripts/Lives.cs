using UnityEngine;
using UnityEngine.SceneManagement; // Needed for scene management
using TMPro; // For TextMeshPro

public class PlayerHealth : MonoBehaviour
{
    public int lives = 5;               // Starting number of lives
    public TMP_Text livesText;          // Reference to UI TextMeshPro element
    public string gameOverSceneName = "GameOver"; // Name of the scene to load when lives are 0

    private void Start()
    {
        UpdateLivesUI();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("damage"))
        {
            lives -= 1;
            lives = Mathf.Max(lives, 0);  // Ensure lives don't go below 0
            UpdateLivesUI();

            Debug.Log("Player hit! Lives remaining: " + lives);

            // Teleport player to "Respawn" point
            GameObject respawnPoint = GameObject.FindGameObjectWithTag("Respawn");
            if (respawnPoint != null)
            {
                transform.position = respawnPoint.transform.position;
            }
            else
            {
                Debug.LogWarning("No object with tag 'Respawn' found in the scene.");
            }

            if (lives <= 0)
            {
                Debug.Log("Game Over!");
                SceneManager.LoadScene(2);
            }
        }
    }

    private void UpdateLivesUI()
    {
        if (livesText != null)
        {
            livesText.text = "Lives: " + lives.ToString();
        }
    }
}
